<?php

Route::get('/', function()
{
	return View::make('guest.index');
});
Route::get('dashboard',array('before'=>'auth','uses'=>'HomeController@dashboard'));
Route::get('login',array('guest.login','uses'=>'GuestController@login'));
Route::post('authenticate','HomeController@authenticate');
Route::post('logout','HomeController@logout');
?>
