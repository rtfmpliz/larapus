@if (Session::has('successMessage'))
<div class="uk-alert uk-alert-success" data-uk-alert>
	<a href="" class="uk-alert-close uk-close"></a>
	<p>{{Session::get('successMessage')}} </p>
</div>
<div class="uk-alert uk-alert-danger" data-uk-alert>
	<a href="" class="uk-alert-close uk-close"></a>
	<p>{{Session::get('errorMessage')}} </p>
</div>

	{{-- expr --}}
@endif